<div class="uap-wrapper">
	<div class="uap-stuffbox">
		<h3 class="uap-h3"><?php esc_html_e('Add/Update Affiliate user', 'uap');?></h3>
		<div class="inside uap-admin-edit">
        	<div class="uap-edit-profile-section-title">
        		<h3><?php echo esc_html__('Affiliate Profile details', 'uap'); ?></h3>
            	<p><?php echo esc_html__('Manage what fields are available for Admin setup from "Showcases->Register Form->Custom Fields" section', 'uap'); ?></p>
            </div>
			<?php echo $data['output'];?>
		</div>
	</div>
</div>
